'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CreateMediaplanPage() {
  const router = useRouter();

  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');

  const [agency, setAgency] = useState('');
  const [advertiser, setAdvertiser] = useState('');
  const [product, setProduct] = useState('');
  const [startAt, setStartAt] = useState('');
  const [endAt, setEndAt] = useState('');
  const [delegateAccountId, setDelegateAccountId] = useState('');
  const [services, setServices] = useState('');

  const [scenariosText, setScenariosText] = useState('');

  useEffect(() => {
    const raw = localStorage.getItem('mp:create-draft');
    if (!raw) return;
    try {
      const d = JSON.parse(raw);
      setName(d.name || '');
      setBrand(d.brand || '');
      setAgency(d.agency || '');
      setAdvertiser(d.advertiser || '');
      setProduct(d.product || '');
      setStartAt(d.startAt || '');
      setEndAt(d.endAt || '');
      setDelegateAccountId(d.delegateAccountId || '');
      setServices(Array.isArray(d.services) ? d.services.join(',') : (d.services || ''));
      setScenariosText(Array.isArray(d.scenarios) ? d.scenarios.join('\n') : (d.scenariosText || ''));
    } catch {}
  }, []);

  const scenarios = useMemo(
    () => scenariosText.split(/\r?\n/).map(s => s.trim()).filter(Boolean),
    [scenariosText]
  );

  const canCreate = name.trim() && brand.trim() && scenarios.length;

  const label = 'block text-sm font-medium text-slate-700';
  const input = 'mt-1 w-full rounded-md border px-3 py-2';
  const card  = 'rounded-xl border p-4 bg-white';

  const saveDraft = () => {
    const draft = {
      name, brand,
      agency, advertiser, product,
      startAt, endAt, delegateAccountId,
      services,
      scenarios, scenariosText
    };
    localStorage.setItem('mp:create-draft', JSON.stringify(draft));
    alert('Черновик сохранён');
  };

  const createCampaign = () => {
    if (!canCreate) {
      alert('Заполните обязательные поля «Название РК», «Бренд» и добавьте минимум один сценарий.');
      return;
    }
    const payload = {
      name, brand,
      agency, advertiser, product,
      startAt, endAt, delegateAccountId,
      services: services.split(',').map(s => s.trim()).filter(Boolean),
      scenarios
    };
    localStorage.setItem('mp:last-created', JSON.stringify(payload));
    router.push('/campaigns/new');
  };

  return (
    <div className="space-y-6">
      <div className={card}>
        <h3 className="text-base font-semibold text-slate-700 mb-3">Обязательные поля (для всей РК)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={label}>Название РК</label>
            <input className={input} required value={name} onChange={e=>setName(e.target.value)} placeholder="Осень-25 / Старт продаж"/>
          </div>
          <div>
            <label className={label}>Бренд</label>
            <input className={input} required value={brand} onChange={e=>setBrand(e.target.value)} placeholder="Romashka"/>
          </div>
        </div>
      </div>

      <div className={card}>
        <h3 className="text-base font-semibold text-slate-700 mb-3">Дополнительные поля (необязательные)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={label}>Агентство</label>
            <input className={input} value={agency} onChange={e=>setAgency(e.target.value)} placeholder="Agency name"/>
          </div>
          <div>
            <label className={label}>Рекламодатель</label>
            <input className={input} value={advertiser} onChange={e=>setAdvertiser(e.target.value)} placeholder="ООО «Ромашка»"/>
          </div>
          <div>
            <label className={label}>Продукт</label>
            <input className={input} value={product} onChange={e=>setProduct(e.target.value)} placeholder="Тариф Х, Линия Y"/>
          </div>
          <div>
            <label className={label}>Старт РК</label>
            <input className={input} type="date" value={startAt} onChange={e=>setStartAt(e.target.value)} />
          </div>
          <div>
            <label className={label}>Окончание РК</label>
            <input className={input} type="date" value={endAt} onChange={e=>setEndAt(e.target.value)} />
          </div>
          <div>
            <label className={label}>Делегирование кампании (Account ID)</label>
            <input className={input} value={delegateAccountId} onChange={e=>setDelegateAccountId(e.target.value)} placeholder="acc_123456"/>
          </div>
          <div className="md:col-span-2">
            <label className={label}>Услуги (ID из справочника)</label>
            <input className={input} value={services} onChange={e=>setServices(e.target.value)} placeholder="101, 205, 309"/>
          </div>
        </div>
      </div>

      <div className={card}>
        <h3 className="text-base font-semibold text-slate-700 mb-3">Сценарии</h3>
        <p className="text-sm text-slate-500 mb-2">Каждый сценарий — на новой строке.</p>
        <textarea
          className="w-full rounded-md border px-3 py-2"
          rows={6}
          value={scenariosText}
          onChange={e=>setScenariosText(e.target.value)}
          placeholder={'Сценарий 1\nСценарий 2\n...'}
        />
        <div className="mt-2 text-sm text-slate-500">Будет создано сценариев: {scenarios.length}</div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          onClick={createCampaign}
          disabled={!canCreate}
          className="rounded-lg px-4 py-2 bg-[#0078D7] text-white disabled:opacity-50"
        >
          Создать рекламную кампанию
        </button>
        <button onClick={saveDraft} className="rounded-lg px-4 py-2 border">
          Сохранить в черновики
        </button>
        <Link
          href="/mediaplan/drafts"
          className="rounded-lg px-4 py-2 border hover:bg-slate-50"
          aria-label="Перейти к черновикам медиапланов"
        >
          Перейти к черновикам
        </Link>
      </div>
    </div>
  );
}
