'use client';
import React, { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { listCampaigns, exportExcel, readCtx, saveCtx, type Campaign } from "@/lib/campaigns";
import { getCampaignStats, type CampaignStats } from "@/lib/campaigns";
import { getFavCampaignIds, toggleFavCampaign, isFavCampaign, getArchivedIds, archiveCampaigns } from "@/lib/archfav";
import { createGroup } from "@/lib/campaigns";
import { logEvent } from "@/lib/analytics";
import CampaignFilters from "@/components/CampaignFilters";
import TagPills from "@/components/TagPills";
import { getCampaignTags, setCampaignTags, getAllTagsMap } from "@/lib/campaigns";
import StatusTypeCell from "@/components/StatusTypeCell";

function Tabs() {
  const path = usePathname();
  const Tab = ({href,label}:{href:string;label:string}) => (
    <Link href={href}
      className={`rounded-full px-3 py-1.5 text-sm ${path===href? "bg-sky-600 text-white":"bg-white text-sky-700 ring-1 ring-sky-600 hover:bg-sky-50"}`}>{label}</Link>
  );
  return (
    <div className="mb-4 flex flex-wrap gap-2">
      <Tab href="/campaigns" label="РК"/>
      <Tab href="/campaigns/groups" label="Группы"/>
      <Tab href="/campaigns/archive" label="Архив"/>
    </div>
  );
}

type GroupMode = "none"|"brand"|"adv"|"tree";
type SortMode = "created_desc"|"created_asc"|"name_asc"|"name_desc";

const dispBrand = (b?:string) => (b && b.trim()) ? b : "Без бренда";
const dispAdv   = (a?:string) => (a && a.trim()) ? a : "Без рекламодателя";

function fmtKM(n:number){
  if (n >= 1_000_000){
    const v = Math.round((n/1_000_000)*10)/10; // одна цифра после запятой
    return String(v).replace('.', ',') + 'м';
  }
  if (n >= 1000){
    const v = Math.round(n/1000);
    return v + 'к';
  }
  return String(n);
}
function fmtPct(clicks:number, imps:number){
  if (!imps) return '0.00%';
  const v = (clicks / imps) * 100;
  return v.toFixed(2).replace('.', ',') + '%';
}
function normStats(st: CampaignStats): CampaignStats {
  const clamp = (n:number)=> Math.max(0, Math.trunc(n));
  return {
    today:     { imps: clamp(st.today.imps),     clicks: clamp(st.today.clicks) },
    yesterday: { imps: clamp(st.yesterday.imps), clicks: clamp(st.yesterday.clicks) },
    total:     { imps: clamp(st.total.imps),     clicks: clamp(st.total.clicks) }
  };
}

function TriStateCheckbox({
  checked, indeterminate, onChange, ariaLabel
}:{checked:boolean; indeterminate:boolean; onChange:()=>void; ariaLabel:string;}){
  const ref = useRef<HTMLInputElement>(null);
  useEffect(()=>{ if(ref.current) ref.current.indeterminate = indeterminate; }, [indeterminate]);
  return <input ref={ref} type="checkbox" checked={checked} onChange={onChange} aria-label={ariaLabel}/>;
}

export default function CampaignsPage(){
  const [mounted, setMounted] = useState(false);
  useEffect(()=>{ setMounted(true); },[]);

  const router = useRouter();
  const params = useSearchParams();

  const fromSuffix = useMemo(()=> {
    const qs = params.toString();
    return qs ? `?from=${encodeURIComponent(qs)}` : "";
  }, [params]);

  const initial = readCtx() as any;
  const [q, setQ] = useState(params.get("q") ?? (initial.q||""));
  const [own, setOwn] = useState((params.get("own") ?? (initial.own? "1":"0")) === "1");
  const [delegated, setDelegated] = useState((params.get("deleg") ?? (initial.delegated? "1":"0")) === "1");
  const [status, setStatus] = useState<"all"|"active"|"inactive">((params.get("status") as any) || (initial.status||"all"));
  const [groupMode, setGroupMode] = useState<GroupMode>((params.get("group") as GroupMode) || (initial.groupBy || "none"));
  const [sort, setSort] = useState<SortMode>((params.get("sort") as SortMode) || "created_desc");
  const [favOnly, setFavOnly] = useState((params.get("fav")||"0")==="1");

  const [tagsMap, setTagsMap] = useState<Record<number, string[]>>(()=>getAllTagsMap());

  // новые 4 фильтра
  const [idFilter, setIdFilter] = useState("");
  const [advFilter, setAdvFilter] = useState("");
  const [brandFilter, setBrandFilter] = useState("");
  const [tagFilter, setTagFilter] = useState("");

  const all = listCampaigns();
  const archivedSet = useMemo(()=> new Set(getArchivedIds()),[]);
  const favSet = useMemo(()=> new Set(getFavCampaignIds()),[]);

  const filtered = useMemo(()=>{
    const term = q.trim().toLowerCase();
    const idTerm = idFilter.trim().toLowerCase();
    const advTerm = advFilter.trim().toLowerCase();
    const brandTerm = brandFilter.trim().toLowerCase();
    const tagTerm = tagFilter.trim().toLowerCase();

    return all
      .filter(c => !archivedSet.has(c.id))
      // универсальный поиск
      .filter(c => !term || [c.id, c.name, c.brand, c.advertiser].some(x=> String(x||"").toLowerCase().includes(term)))
      // доп. фильтр: ID
      .filter(c => !idTerm || String(c.id).toLowerCase().includes(idTerm))
      // доп. фильтр: рекламодатель
      .filter(c => !advTerm || String(c.advertiser || "").toLowerCase().includes(advTerm))
      // доп. фильтр: бренд
      .filter(c => !brandTerm || String(c.brand || "").toLowerCase().includes(brandTerm))
      // доп. фильтр: тег (пока ищем по имени, потом подключим реальные теги)
      .filter(c => { const wanted = tagTerm.split(",").map(s=>s.trim().toLowerCase()).filter(Boolean); if (!tagTerm || !wanted.length) return true; const actual = (tagsMap[c.id] || getCampaignTags(c.id)).map(t=>t.toLowerCase()); return wanted.some(w => actual.includes(w)); })
      // статус
      .filter(c => status==="all" ? true : (status==="active" ? c.status==="Активна" : c.status!=="Активна"))
      // свои / делег
      .filter(c => own ? c.type!=="Делегированная" : true)
      .filter(c => delegated ? c.type==="Делегированная" : true)
      // избранные
      .filter(c => favOnly ? favSet.has(c.id) : true);
  }, [all, archivedSet, q, status, own, delegated, favOnly, favSet, idFilter, advFilter, brandFilter, tagFilter, tagsMap]);

  const sorted = useMemo(()=>{
    const arr = [...filtered];
    const byName = (a:Campaign,b:Campaign)=> a.name.localeCompare(b.name, "ru");
    const byCreated = (a:Campaign,b:Campaign)=> (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    switch (sort) {
      case "name_asc":  return arr.sort(byName);
      case "name_desc": return arr.sort((a,b)=>-byName(a,b));
      case "created_asc": return arr.sort(byCreated);
      default: return arr.sort((a,b)=> -byCreated(a,b));
    }
  }, [filtered, sort]);

  const idsByBrand = useMemo(()=> {
    const m = new Map<string, Set<number>>();
    sorted.forEach(c=>{ const b = dispBrand(c.brand); if(!m.has(b)) m.set(b, new Set()); m.get(b)!.add(c.id); });
    return m;
  }, [sorted]);
  const idsByAdv = useMemo(()=> {
    const m = new Map<string, Set<number>>();
    sorted.forEach(c=>{ const a = dispAdv(c.advertiser); if(!m.has(a)) m.set(a, new Set()); m.get(a)!.add(c.id); });
    return m;
  }, [sorted]);
  const idsByAdvBrand = useMemo(()=> {
    const m = new Map<string, Map<string, Set<number>>>();
    sorted.forEach(c=>{
      const a = dispAdv(c.advertiser);
      const b = dispBrand(c.brand);
      if(!m.has(a)) m.set(a, new Map());
      const mm = m.get(a)!;
      if(!mm.has(b)) mm.set(b, new Set());
      mm.get(b)!.add(c.id);
    });
    return m;
  }, [sorted]);

  const [selected, setSelected] = useState<Set<number>>(new Set());
  const addIds    = (ids:Set<number>) => setSelected(prev=>{ const n=new Set(prev); ids.forEach(id=>n.add(id)); return n; });
  const removeIds = (ids:Set<number>) => setSelected(prev=>{ const n=new Set(prev); ids.forEach(id=>n.delete(id)); return n; });

  const toggleSel = (id:number)=> setSelected(prev=>{ const n=new Set(prev); n.has(id)?n.delete(id):n.add(id); return n; });

  const toggleAdvAll = (advLabel:string) => {
    const ids = idsByAdv.get(advLabel) || new Set<number>();
    const allChecked = Array.from(ids).every(id => selected.has(id));
    allChecked ? removeIds(ids) : addIds(ids);
  };

  const toggleBrandAll = (brandLabel:string) => {
    const ids = idsByBrand.get(brandLabel) || new Set<number>();
    const allChecked = Array.from(ids).every(id => selected.has(id));
    allChecked ? removeIds(ids) : addIds(ids);
  };

  const toggleBrandUnderAdv = (advLabel:string, brandLabel:string) => {
    const ids = idsByAdvBrand.get(advLabel)?.get(brandLabel) || new Set<number>();
    const allChecked = Array.from(ids).every(id => selected.has(id));
    allChecked ? removeIds(ids) : addIds(ids);
  };

  const clearAllSelection = ()=> setSelected(new Set());

  const tree = useMemo(()=> {
    if (groupMode==="none") return { "Все кампании": { "__flat": sorted } } as any;
    if (groupMode==="brand") {
      const m:any = {};
      sorted.forEach(c=>{
        const k = dispBrand(c.brand);
        (m[k] ||= { "__flat": [] }).__flat.push(c);
      });
      return m;
    }
    if (groupMode==="adv") {
      const m:any = {};
      sorted.forEach(c=>{
        const k = dispAdv(c.advertiser);
        (m[k] ||= { "__flat": [] }).__flat.push(c);
      });
      return m;
    }
    const m:any = {};
    sorted.forEach(c=>{
      const a = dispAdv(c.advertiser);
      const b = dispBrand(c.brand);
      (m[a] ||= {});
      (m[a][b] ||= { "__flat": [] }).__flat.push(c);
    });
    return m;
  }, [sorted, groupMode]);

  const [collapsedAdv, setCollapsedAdv] = useState<Record<string, boolean>>({});
  const [collapsedBucket, setCollapsedBucket] = useState<Record<string, boolean>>({});
  const [collapsedBrand, setCollapsedBrand] = useState<Record<string, boolean>>({});
  const [expandedBrandAll, setExpandedBrandAll] = useState<Record<string, boolean>>({});
  const [expandedFlatAll, setExpandedFlatAll] = useState<Record<string, boolean>>({});

  const ids = useMemo(()=> Array.from(selected), [selected]);
  const gotoDashboard = ()=> { if(!ids.length) return; logEvent("open_dashboard",{ids, via:"groups"}); router.push(`/dashboard?ids=${ids.join(",")}`); };
  const gotoBuilder  = ()=> { if(!ids.length) return; logEvent("open_builder",{ids, via:"groups"});  router.push(`/builder?ids=${ids.join(",")}`); };
  const exportAction = ()=> exportExcel(sorted.filter(c=>selected.has(c.id)));
  const archiveAction = ()=> { if(!ids.length) return; if(confirm(`Архивировать ${ids.length} камп.?`)){ archiveCampaigns(ids); setSelected(new Set()); router.refresh(); alert("Перемещено в «Архив»."); } };
  const saveGroupAction = ()=> {
    if(!ids.length) return;
    const name = prompt("Название группы","Новая группа");
    if(!name) return;
    const desc = prompt("Описание группы","") || "";
    const g = createGroup(name, ids, desc);
    alert(`Группа «${g.name}» сохранена (${g.campaignIds.length} камп.).`);
  };

  const editTags = (id:number) => {
    const curr = tagsMap[id] || getCampaignTags(id);
    const next = prompt("Теги (через запятую)", curr.join(", "));
    if (next===null) return;
    const tags = next.split(",").map(s=>s.trim()).filter(Boolean);
    setCampaignTags(id, tags);
    setTagsMap(prev=>({ ...prev, [id]: tags }));
  };


  useEffect(()=>{
    saveCtx({ q, own, delegated, status, groupBy: groupMode });
    const qs = new URLSearchParams();
    if (q) qs.set("q", q);
    if (groupMode!=="none") qs.set("group", groupMode);
    qs.set("sort", sort);
    qs.set("fav", favOnly ? "1":"0");
    qs.set("own",  own ? "1":"0");
    qs.set("deleg",delegated ? "1":"0");
    if(status!=="all") qs.set("status", status);
    router.replace(`/campaigns?${qs.toString()}`);
  }, [q, groupMode, sort, favOnly, own, delegated, status, router]);

  const TableHead = () => (
    <thead>
      <tr>
        <th className="bg-gray-100 p-2 w-8"></th>
        <th className="bg-gray-100 p-2 w-8"></th>
        <th className="bg-gray-100 p-2 text-left">ID</th>
        <th className="bg-gray-100 p-2 text-left w-16">Сост.</th>
        <th className="bg-gray-100 p-2 text-left">Название / Даты</th>
        <th className="bg-gray-100 p-2 text-right w-36">Показы</th>
        <th className="bg-gray-100 p-2 text-right w-36">Клики</th>
        <th className="bg-gray-100 p-2 text-right w-36">CTR%</th>
        <th className="bg-gray-100 p-2 text-right">Действия</th>
      </tr>
    </thead>
  );

  const Row = ({c}:{c:Campaign}) => {
  const st = normStats(getCampaignStats(c.id));
  return (
    <tr key={c.id} className="odd:bg-white even:bg-gray-50 hover:bg-sky-50">
      <td className="border-t p-2">
        <input
          type="checkbox"
          checked={selected.has(c.id)}
          onChange={()=>toggleSel(c.id)}
          aria-label="Выбрать кампанию"
        />
      </td>
      <td className="border-t p-2">
        <button aria-label={isFavCampaign(c.id) ? "Убрать из избранного" : "В избранное"} onClick={()=>{ toggleFavCampaign(c.id); router.refresh(); }} className="text-lg leading-none">
          {isFavCampaign(c.id) ? "⭐" : "☆"}
        </button>
      </td>
      <td className="border-t p-2 font-mono text-sky-700 underline-offset-2 hover:underline">
        <Link href={`/campaigns/${c.id}${fromSuffix}`}>{c.id}</Link>
      </td>
      <td className="border-t p-2"><StatusTypeCell type={c.type} status={c.status} /></td>
      <td className="border-t p-2 text-sky-700 underline-offset-2 hover:underline">
        <Link href={`/campaigns/${c.id}${fromSuffix}`}>{c.name}</Link>
        <div className="text-xs text-gray-500">
          Создана: {new Date(c.createdAt).toLocaleDateString("ru-RU")}
        </div>
        <TagPills tags={(tagsMap[c.id] || getCampaignTags(c.id))} onAdd={() => addTagsQuick(c.id)} onRemove={(t) => removeTag(c.id, t)} />
      </td>

      {/* Показы */}
      <td className="border-t p-2 text-right">{fmtKM(Math.abs((st.total?.imps)||0))}</td>
      {/* Клики */}
      <td className="border-t p-2 text-right">{fmtKM(Math.abs((st.total?.clicks)||0))}</td>
      {/* CTR% */}
      <td className="border-t p-2 text-right"><span className="font-mono text-xs text-emerald-700">{fmtPct(Math.abs((st.total?.clicks)||0), Math.abs((st.total?.imps)||0))}</span></td>

      <td className="border-t p-2 text-right" data-no-rownav>
          <button onClick={()=>editTags(c.id)} title="Теги кампании" className="mr-1 rounded-full bg-white px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-600">🏷</button>
        <Link href={`/dashboard?ids=${c.id}`} title="Дашборд" className="mr-1 rounded-full bg-sky-600 px-2 py-1 text-xs text-white">📊</Link>
        <Link href={`/builder?ids=${c.id}`}   title="Конструктор" className="mr-1 rounded-full bg-white px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-600">🧩</Link>
        <button onClick={()=>exportExcel([c])} title="Экспорт Excel" className="mr-1 rounded-full bg-white px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-600">⬇️</button>
        <button
          onClick={()=>{ if(confirm("Архивировать кампанию?")){ archiveCampaigns([c.id]); router.refresh(); }}}
          title="Архивировать"
          className="rounded-full bg-white px-2 py-1 text-xs text-amber-700 ring-1 ring-amber-600"
        >
          🗄️
        </button>
      </td>
    </tr>
  );
};
  return (
    <div className="mx-auto max-w-7xl p-6">
      <Tabs/>

      {!mounted ? (
        <div className="rounded-2xl border bg-white p-8 text-gray-500">Загрузка…</div>
      ) : (
        <>
          <CampaignFilters
            q={q}
            onQChange={setQ}
            status={status}
            onStatusChange={setStatus}
            groupMode={groupMode}
            onGroupChange={(gm)=>{ setGroupMode(gm); setSelected(new Set()); }}
            sort={sort}
            onSortChange={setSort}
            own={own}
            onOwnChange={setOwn}
            delegated={delegated}
            onDelegatedChange={setDelegated}
            favOnly={favOnly}
            onFavChange={setFavOnly}
            idFilter={idFilter}
            onIdFilterChange={setIdFilter}
            advFilter={advFilter}
            onAdvFilterChange={setAdvFilter}
            brandFilter={brandFilter}
            onBrandFilterChange={setBrandFilter}
            tagFilter={tagFilter}
            onTagFilterChange={setTagFilter}
          />

          {ids.length>0 && (
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-xl bg-sky-50 px-3 py-2 ring-1 ring-sky-200">
              <div className="text-sm text-sky-900">Выбрано РК: <b>{ids.length}</b></div>
              <button onClick={gotoDashboard} className="rounded-full bg-sky-600 px-3 py-1 text-xs text-white" title="Дашборд">📊</button>
              <button onClick={gotoBuilder}  className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600" title="Конструктор">🧩</button>
              <button onClick={exportAction} className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600" title="Экспорт Excel">⬇️</button>
              <button onClick={archiveAction} className="rounded-full bg-white px-3 py-1 text-xs text-amber-700 ring-1 ring-amber-600" title="Архивировать">🗄️</button>
              <button onClick={saveGroupAction} className="rounded-full bg-white px-3 py-1 text-xs text-emerald-700 ring-1 ring-emerald-600" title="Сохранить в группу">🗂️ Сохранить</button>
              <button onClick={clearAllSelection} className="ml-auto rounded-full bg-white px-3 py-1 text-xs text-gray-700 ring-1 ring-gray-300" title="Сбросить">✖️</button>
            </div>
          )}

          <div className="space-y-6">
            { (["none","brand","adv"] as GroupMode[]).includes(groupMode) ? (
              Object.entries(tree).map(([label, bucket]:any)=> {
                const key = `${groupMode}::${label}`;
                const isCollapsed = !!collapsedBucket[key];
                const showAll = !!expandedFlatAll[key];
                const rows: Campaign[] = showAll ? bucket.__flat : bucket.__flat.slice(0, 10);
                const idsSet = groupMode==="brand"
                  ? (idsByBrand.get(label) || new Set<number>())
                  : (idsByAdv.get(label) || new Set<number>());
                const all = Array.from(idsSet).every(id => selected.has(id));
                const some = !all && Array.from(idsSet).some(id => selected.has(id));
                const total = bucket.__flat.length;
                return (
                  <section key={label} className="rounded-2xl border bg-white p-4 shadow-sm">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <TriStateCheckbox
                          checked={all}
                          indeterminate={some}
                          onChange={()=> groupMode==="brand" ? toggleBrandAll(label) : toggleAdvAll(label)}
                          ariaLabel={groupMode==="brand" ? `Выбрать бренд ${label}` : `Выбрать рекламодателя ${label}`}
                        />
                        <button
                          onClick={()=> setCollapsedBucket(prev=>({ ...prev, [key]: !prev[key] }))}
                          className="rounded-full bg-sky-50 px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-200"
                        >
                          {isCollapsed ? "▸" : "▾"}
                        </button>
                        <div className="text-left text-xl font-semibold">
                          {label}
                          <span className="ml-2 rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">{total}</span>
                        </div>
                      </div>
                      {!isCollapsed && total > 10 && (
                        <button
                          onClick={()=> setExpandedFlatAll(prev=>({ ...prev, [key]: false }))}
                          className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600"
                        >
                          Свернуть список
                        </button>
                      )}
                    </div>
                    {!isCollapsed && (
                      <div className="overflow-auto">
                        <table className="w-full border-collapse text-sm">
                          <TableHead/>
                          <tbody>
                            {rows.map((c:Campaign)=> <Row key={c.id} c={c} />)}
                            {rows.length===0 && (<tr><td colSpan={9} className="py-8 text-center text-gray-500">Ничего не найдено</td></tr>)}
                          </tbody>
                        </table>
                        {total > 10 && (
                          <div className="border-t bg-white px-3 py-2 flex justify-end">
                            <button
                              onClick={()=> setExpandedFlatAll(prev=>({ ...prev, [key]: !prev[key] }))}
                              className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600"
                            >
                              {showAll ? "Свернуть список" : `Показать ещё (${total - 10})`}
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </section>
                );
              })
            ) : (
              Object.entries(tree).map(([advLabel, brands]:any)=>(
                <section key={advLabel} className="rounded-2xl border bg-white p-4 shadow-sm">
                  <div className="mb-2 flex items-center gap-3">
                    {(()=> {
                      const ids = idsByAdv.get(advLabel) || new Set<number>();
                      const all = Array.from(ids).every(id => selected.has(id));
                      const some = !all && Array.from(ids).some(id => selected.has(id));
                      return (
                        <TriStateCheckbox
                          checked={all} indeterminate={some}
                          onChange={()=>toggleAdvAll(advLabel)}
                          ariaLabel={`Выбрать рекламодателя ${advLabel}`}
                        />
                      );
                    })()}
                    <button
                      onClick={()=> setCollapsedAdv(prev=>({ ...prev, [advLabel]: !prev[advLabel] }))}
                      className="rounded-full bg-sky-50 px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-200"
                      title={collapsedAdv[advLabel] ? "Развернуть" : "Свернуть"}
                    >
                      {collapsedAdv[advLabel] ? "▸" : "▾"}
                    </button>
                    <div className="text-left text-xl font-semibold">
                      {advLabel}
                      <span className="ml-2 rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">
                        {(idsByAdv.get(advLabel) || new Set<number>()).size}
                      </span>
                    </div>
                  </div>

                  {!collapsedAdv[advLabel] && Object.entries(brands).map(([brandLabel, bucket]:any)=> {
                    const brandKey = `${advLabel}::${brandLabel}`;
                    const isCollapsed = !!collapsedBrand[brandKey];
                    const showAll = !!expandedBrandAll[brandKey];
                    const rows: Campaign[] = showAll ? bucket.__flat : bucket.__flat.slice(0, 10);
                    const total = bucket.__flat.length;
                    return (
                      <div key={brandKey} className="mb-4 rounded-xl border bg-white">
                        <div className="flex items-center justify-between px-3 py-2">
                          <div className="flex items-center gap-3">
                            {(()=> {
                              const ids = idsByAdvBrand.get(advLabel)?.get(brandLabel) || new Set<number>();
                              const all = Array.from(ids).every(id => selected.has(id));
                              const some = !all && Array.from(ids).some(id => selected.has(id));
                              return (
                                <TriStateCheckbox
                                  checked={all} indeterminate={some}
                                  onChange={()=>toggleBrandUnderAdv(advLabel, brandLabel)}
                                  ariaLabel={`Выбрать бренд ${brandLabel}`}
                                />
                              );
                            })()}
                            <button
                              onClick={()=> setCollapsedBrand(prev=>({ ...prev, [brandKey]: !prev[brandKey] }))}
                              className="rounded-full bg-sky-50 px-2 py-1 text-xs text-sky-700 ring-1 ring-sky-200"
                            >
                              {isCollapsed ? "▸" : "▾"}
                            </button>
                            <div className="text-left font-semibold">{brandLabel}
                              <span className="ml-2 rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">{total}</span>
                            </div>
                          </div>
                          {!isCollapsed && total > 10 && (
                            <button
                              onClick={()=> setExpandedBrandAll(prev=>({ ...prev, [brandKey]: false }))}
                              className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600"
                            >
                              Свернуть список
                            </button>
                          )}
                        </div>
                        {!isCollapsed && (
                          <div className="overflow-auto">
                            <table className="w-full border-collapse text-sm">
                              <TableHead/>
                              <tbody>
                                {rows.map((c:Campaign)=> <Row key={c.id} c={c} />)}
                              </tbody>
                            </table>
                            {total > 10 && (
                              <div className="border-t bg-white px-3 py-2 flex justify-end">
                                <button
                                  onClick={()=> setExpandedBrandAll(prev=>({ ...prev, [brandKey]: !prev[brandKey] }))}
                                  className="rounded-full bg-white px-3 py-1 text-xs text-sky-700 ring-1 ring-sky-600"
                                >
                                  {showAll ? "Свернуть список" : `Показать ещё (${total - 10})`}
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </section>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
