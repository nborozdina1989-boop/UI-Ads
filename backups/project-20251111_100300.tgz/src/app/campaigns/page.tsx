'use client'
export { default } from '@/app/_pages/CampaignsPage'
