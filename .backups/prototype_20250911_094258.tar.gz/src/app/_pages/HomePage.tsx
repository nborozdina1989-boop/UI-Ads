'use client';
import React from "react";
import Link from "next/link";

export default function HomePage() {
  return (
    <div className="mx-auto max-w-6xl p-8">
      <header className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-bold">AdRiver Prototype</h1>
          <p className="text-sm text-gray-600">Лёгкий прототип без бэка: кампании, конструктор и дашборд.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Primary href="/campaigns">Кампании</Primary>
          <Secondary href="/builder">Конструктор</Secondary>
          <Secondary href="/dashboard">Дашборд</Secondary>
        </div>
      </header>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Рабочие экраны</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <Card href="/campaigns" title="Рекламные кампании" desc="Список РК по брендам, поиск и быстрые действия." />
          <Card href="/builder"   title="Конструктор отчётов" desc="DnD: Фильтры / Строки / Метрики + предпросмотр." />
          <Card href="/dashboard" title="Дашборд"             desc="KPI и таблица. Фильтры: страна, город, устройство, кампания." />
        </div>
      </section>

      <footer className="mt-10 text-center text-xs text-gray-500">
        Прототип без бэка · Tailwind · HTML5 Drag&Drop
      </footer>
    </div>
  );
}

/* ---------- Малые компоненты ---------- */
function Card({ href, title, desc }:{ href:string; title:string; desc:string }) {
  return (
    <Link href={href} className="block rounded-xl border bg-white p-5 shadow-sm ring-1 ring-transparent transition hover:shadow-md hover:ring-sky-200">
      <div className="mb-1 text-base font-semibold">{title}</div>
      <div className="text-sm text-gray-600">{desc}</div>
    </Link>
  );
}

function Primary({ href, children }:{ href:string; children:React.ReactNode }) {
  return (
    <Link href={href} className="rounded-full bg-sky-600 px-4 py-2 text-sm text-white hover:bg-sky-700">
      {children}
    </Link>
  );
}
function Secondary({ href, children }:{ href:string; children:React.ReactNode }) {
  return (
    <Link href={href} className="rounded-full bg-white px-4 py-2 text-sm text-sky-700 ring-1 ring-sky-600 hover:bg-sky-50">
      {children}
    </Link>
  );
}
