'use client';
import Link from "next/link";
import React from "react";

export default function UploadCombinedStubPage() {
  return (
    <div className="mx-auto max-w-6xl p-8">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Загрузка медиаплана</h1>
          <p className="text-sm text-gray-600">
            Скачайте шаблон или загрузите ваш .xlsx/.csv. После загрузки здесь же появится разметка.
            В этой сборке функционал отключён — только макет потока.
          </p>
        </div>

        {/* Кнопки действий справа */}
        <div className="flex items-center gap-2">
          <Link
            href="/campaigns"
            className="rounded-full border px-4 py-2 text-sm hover:bg-gray-50"
            title="Перейти к списку рекламных кампаний"
          >
            К списку рекламных кампаний
          </Link>

          {/* Кнопка скачивания — неактивная */}
          <button
            type="button"
            aria-disabled="true"
            className="cursor-not-allowed rounded-full px-4 py-2 text-sm text-sky-700 ring-1 ring-sky-300/70 opacity-50"
            title="Недоступно в прототипе"
          >
            Скачать шаблон
          </button>
          <a href="/mediaplan/drafts" className="rounded-full bg-white px-4 py-2 text-sm text-sky-700 ring-1 ring-sky-600 hover:bg-sky-50">Черновики</a>
        </div>
      </header>

      {/* Дропзона — неактивная */}
      <label
        className="mb-6 flex h-40 w-full cursor-not-allowed items-center justify-center rounded-2xl border-2 border-dashed border-gray-300/70 bg-gray-50 text-center"
        title="Недоступно в прототипе"
      >
        <span className="text-gray-400">
          <b>Обзор…</b> Файл не выбран. <div className="text-xs">Или перетащите файл сюда</div>
        </span>
        <input type="file" disabled className="hidden" />
      </label>

      <div className="mb-6 text-sm text-gray-500">Файл не загружен.</div>

      {/* Разметка — на том же экране (заглушка) */}
      <section className="grid gap-6 md:grid-cols-3">
        {/* Табличная зона (скелет) */}
        <div className="md:col-span-2">
          <div className="mb-3 text-sm font-semibold">Таблица медиаплана (предпросмотр)</div>
          <div className="overflow-hidden rounded-xl border">
            <div className="grid grid-cols-6 gap-px bg-gray-200">
              {Array.from({length: 6}).map((_,i)=>(
                <div key={i} className="bg-gray-100 p-2 text-left text-xs font-medium text-gray-600">Колонка {i+1}</div>
              ))}
              {Array.from({length: 10}).map((_,r)=>(
                <React.Fragment key={r}>
                  {Array.from({length: 6}).map((_,c)=>(
                    <div key={c} className="bg-white p-2 text-xs text-gray-400">—</div>
                  ))}
                </React.Fragment>
              ))}
            </div>
          </div>

          <details className="mt-4 rounded-lg border bg-white p-4">
            <summary className="cursor-pointer text-sm font-medium">Предупреждения / ошибки</summary>
            <p className="mt-2 text-sm text-gray-600">Нет данных — разметка не выполнялась.</p>
          </details>
        </div>

        {/* Правая панель — чек-лист разметки */}
        <aside className="space-y-4">
          <div className="rounded-lg border bg-white p-4">
            <div className="mb-2 text-sm font-semibold">Параметры кампании (ячейки)</div>
            <div className="space-y-2 text-sm">
              <Item required label="Бренд" />
              <Item required label="Название РК" />
              <details>
                <summary className="cursor-pointer text-gray-700">Дополнительно</summary>
                <div className="mt-2 space-y-2">
                  <Item label="Агентство" />
                  <Item label="Рекламодатель" />
                  <Item label="Продукт" />
                  <Item label="Старт РК" />
                  <Item label="Окончание РК" />
                  <Item label="Делегирование кампании (Account ID)" />
                  <Item label="Услуги (ID из справочника)" />
                </div>
              </details>
            </div>
          </div>

          <div className="rounded-lg border bg-white p-4">
            <div className="mb-2 text-sm font-semibold">Столбцы позиций</div>
            <div className="space-y-2 text-sm">
              <Item required label="Название позиции" />
              <Item required label="Поставщик" />
              <Item required label="Формат размещения" />
              <Item required label="Хостинг видео" />
              <Item required label="Среда размещения" />
              <Item required label="Тип измерения" />
              <Item required label="Название баннера" />
              <Item required label="URL баннера" />
              <details>
                <summary className="cursor-pointer text-gray-700">Дополнительно</summary>
                <div className="mt-2 space-y-2">
                  <Item label="Время начала" />
                  <Item label="Время окончания" />
                  <Item label="Тип кода (code_id)" />
                  <Item label="Делегирование поставщиков" />
                  <Item label="Трекерный сайт (Web/iOS/Android)" />
                  <Item label="Mediascope / URL аудитора / VAST версия / Редирект" />
                  <Item label="Макросы: exss, ЕРИР, Bundle ID, GAID/IDFA, Внешний ID" />
                  <Item label="Дин. параметры клика / показа" />
                  <Item label="Гео / Целевая аудитория" />
                </div>
              </details>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {/* Главное: теперь ведём на промежуточный экран */}
            <Link href="/campaigns/new" className="rounded-full bg-sky-600 px-4 py-2 text-sm text-white hover:bg-sky-700">
              Создать кампанию
            </Link>
            <Link href="/campaigns" className="rounded-full border px-4 py-2 text-sm hover:bg-gray-50">
              К списку рекламных кампаний
            </Link>
          </div>
        </aside>
      </section>
    </div>
  );
}

/* Малый компонент элемента чек-листа */
function Item({ label, required=false }:{ label:string; required?:boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className={required ? "font-medium" : ""}>{label}</span>
      <span
        className="select-none rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-500"
        title="Не размечено (заглушка)"
      >
        —
      </span>
    </div>
  );
}
