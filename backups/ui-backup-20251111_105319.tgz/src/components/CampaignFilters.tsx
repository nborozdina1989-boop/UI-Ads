"use client";
import React, { useState, useRef } from "react";
import Link from "next/link";

type GroupMode = "none" | "brand" | "adv" | "tree";
type SortMode = "created_desc" | "created_asc" | "name_asc" | "name_desc";

type TokenInputProps = {
  values: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  suggestions?: string[];
  className?: string;
};
function TokenInput({ values, onChange, placeholder, suggestions, className }: TokenInputProps) {
  const [text, setText] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const commit = (raw: string) => {
    const parts = raw.split(/[,\s]+/).map(s => s.trim()).filter(Boolean);
    if (!parts.length) return;
    const set = new Set(values);
    parts.forEach(p => set.add(p));
    onChange(Array.from(set));
    setText("");
  };
  const onKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); commit(text); }
    if (e.key === "Backspace" && text === "" && values.length) {
      const next = values.slice(0, -1);
      onChange(next);
    }
  };
  const removeAt = (i: number) => {
    const next = values.slice();
    next.splice(i, 1);
    onChange(next);
    inputRef.current?.focus();
  };
  const id = suggestions ? `ti-${(placeholder||"").replace(/\s+/g,"-")}` : undefined;
  return (
    <div className={`min-w-[140px] flex items-center flex-wrap gap-1 rounded-xl border border-slate-200 px-2 py-1.5 ${className||""}`}>
      {values.map((v, i) => (
        <span key={`${v}-${i}`} className="flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-700">
          {v}
          <button onClick={()=>removeAt(i)} className="ml-1 text-slate-500 hover:text-slate-700">×</button>
        </span>
      ))}
      <input
        ref={inputRef}
        list={suggestions ? id : undefined}
        value={text}
        onChange={(e)=>setText(e.target.value)}
        onBlur={()=>commit(text)}
        onKeyDown={onKeyDown}
        placeholder={values.length ? "" : (placeholder || "")}
        className="flex-1 min-w-[80px] outline-none text-sm placeholder:text-slate-400"
      />
      {suggestions && (
        <datalist id={id}>
          {suggestions.map(s => <option key={s} value={s} />)}
        </datalist>
      )}
    </div>
  );
}

interface Props {
  q: string;
  onQChange: (v: string) => void;
  own: boolean;
  onOwnChange: (v: boolean) => void;
  delegated: boolean;
  onDelegatedChange: (v: boolean) => void;
  status: "all" | "active" | "inactive";
  onStatusChange: (v: "all" | "active" | "inactive") => void;
  favOnly: boolean;
  onFavChange: (v: boolean) => void;
  groupMode: GroupMode;
  onGroupChange: (v: GroupMode) => void;
  sort: SortMode;
  onSortChange: (v: SortMode) => void;

  idFilter: string[];
  onIdFilterChange: (v: string[]) => void;
  brandFilter: string[];
  onBrandFilterChange: (v: string[]) => void;
  advFilter: string[];
  onAdvFilterChange: (v: string[]) => void;
  tagFilter: string[];
  onTagFilterChange: (v: string[]) => void;
  measFilter: string[];
  onMeasFilterChange: (v: string[]) => void;
  allMeasures: string[];

  onReset: () => void;
}

export default function CampaignFilters(props: Props) {
  const {
    q,onQChange,own,onOwnChange,delegated,onDelegatedChange,
    status,onStatusChange,favOnly,onFavChange,
    groupMode,onGroupChange,sort,onSortChange,
    idFilter,onIdFilterChange,brandFilter,onBrandFilterChange,
    advFilter,onAdvFilterChange,tagFilter,onTagFilterChange,
    measFilter,onMeasFilterChange,allMeasures,
    onReset
  } = props;

  const [showAdvanced, setShowAdvanced] = useState(true);
  const btnBase = "rounded-full px-3 py-1.5 text-sm transition-colors";
  const btnOff = "bg-white text-slate-700 hover:bg-slate-50 border border-slate-200";
  const btnOn  = "bg-sky-50 text-sky-700 border border-sky-200";

  return (
    <div className="mb-4 rounded-2xl border border-slate-100 bg-white px-4 py-3 shadow-sm">
      <div className="flex flex-wrap items-center gap-3">
        <input
          value={q}
          onChange={(e) => onQChange(e.target.value)}
          placeholder="Поиск по названию / ID / бренду / рекламодателю"
          className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-400 focus:ring-0"
        />
        <button
          type="button"
          onClick={() => setShowAdvanced((p) => !p)}
          className="flex items-center gap-1 rounded-full bg-white px-3 py-1.5 text-sm text-slate-700 border border-slate-200 hover:bg-slate-50"
        >
          {showAdvanced ? "Скрыть фильтры" : "Фильтры"}
          <span className="text-xs">{showAdvanced ? "▴" : "▾"}</span>
        </button>
        <button
          type="button"
          onClick={onReset}
          className="text-sm text-sky-600 hover:text-sky-700"
        >
          Сбросить
        </button>
        <Link
          href="/mediaplan/upload"
          className="ml-auto rounded-full bg-sky-600 px-3 py-1.5 text-sm text-white hover:bg-sky-700 whitespace-nowrap"
        >
          Добавить медиаплан
        </Link>
      </div>

      {showAdvanced && (
        <>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => onOwnChange(!own)} className={`${btnBase} ${own ? btnOn : btnOff}`}>Свои</button>
            <button type="button" onClick={() => onDelegatedChange(!delegated)} className={`${btnBase} ${delegated ? btnOn : btnOff}`}>Делегированные</button>
            <button type="button" onClick={() => onStatusChange(status === "active" ? "all" : "active")} className={`${btnBase} ${status === "active" ? btnOn : btnOff}`}>Включенные</button>
            <button type="button" onClick={() => onStatusChange(status === "inactive" ? "all" : "inactive")} className={`${btnBase} ${status === "inactive" ? btnOn : btnOff}`}>Завершенные</button>
            <button type="button" onClick={() => onFavChange(!favOnly)} className={`${btnBase} ${favOnly ? btnOn : btnOff} flex items-center gap-1`}><span>⭐</span> Избранное</button>

            <select value={groupMode} onChange={(e) => onGroupChange(e.target.value as GroupMode)} className="rounded-xl border border-slate-200 px-3 py-1.5 text-sm focus:border-sky-400">
              <option value="none">Без группировки</option>
              <option value="brand">Бренд</option>
              <option value="adv">Рекламодатель</option>
              <option value="tree">Иерархия</option>
            </select>

            <select value={sort} onChange={(e) => onSortChange(e.target.value as SortMode)} className="rounded-xl border border-slate-200 px-3 py-1.5 text-sm focus:border-sky-400">
              <option value="created_desc">Сначала новые</option>
              <option value="created_asc">Сначала старые</option>
              <option value="name_asc">Название A→Z</option>
              <option value="name_desc">Название Z→A</option>
            </select>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400 pr-2">Доп. поиск:</span>
            <TokenInput values={idFilter} onChange={onIdFilterChange} placeholder="ID" className="w-[160px]" />
            <TokenInput values={brandFilter} onChange={onBrandFilterChange} placeholder="Бренд" className="w-[180px]" />
            <TokenInput values={advFilter} onChange={onAdvFilterChange} placeholder="Рекламодатель" className="w-[200px]" />
            <TokenInput values={tagFilter} onChange={onTagFilterChange} placeholder="Поиск по тегам" className="w-[220px]" />
            <TokenInput values={measFilter} onChange={onMeasFilterChange} placeholder="Тип измерения" suggestions={allMeasures} className="w-[220px]" />
          </div>
        </>
      )}
    </div>
  );
}
